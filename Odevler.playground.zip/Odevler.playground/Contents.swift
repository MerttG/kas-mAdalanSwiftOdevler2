import UIKit

//Km yi mil e dönüştüren ödev sorusu

class Soru1 {
    func soru1(km:Double) -> Double{
        let  mile = km * 0.621
        return  mile
    }
}

let s1 = Soru1()
let sonuc = s1.soru1(km: 10)
print("Km'nin Mile Dönüşmesi Sonucu : \(sonuc)")//Cevap: 6.21

//Dikdörtgen alanı Ödev sorusu

class Soru2 {
    func soru2(Akenar:Int, BKenar:Int){
        let alan = Akenar * BKenar
        print("Dikdörtgenin alan hesabının sonucu : \(alan)")
    }
}
let s2 = Soru2()
s2.soru2(Akenar: 9, BKenar: 6)



//Faktöriyel ödevi

class soru3 {
    func faktoriyelHesapla(n:Int) -> Int {
        if n == 0 || n == 1 {
            return 1
        }else {
            return n * faktoriyelHesapla(n: n-1)
        
        }
    }
}

let faktoriyel = soru3()
let eldeEdilen = faktoriyel.faktoriyelHesapla(n: 7)
print("\(eldeEdilen)")


//Girilen kelimede kaç tane e vardır sorusu

class soru4 {
    func harfSay(kelime:String){
        var sayac = 0
        for karakter in kelime {
            if  karakter == "e" || karakter == "E" {
                sayac += 1
            }
        }
        print("Girdiğiniz kelimede toplam \(sayac) kadar e/E harfi bulunmaktadır.")
    }
}

let adet = soru4()
adet.harfSay(kelime: "matematik")


// Parametre olarak girilen kenar sayısına göre her bir iç açıyı hesaplayıp sonucu geri gönderen metod yazınız.
class Soru5 {
    func icAciToplami(kenarSayisi: Int) -> Double {
        let toplam = Double((kenarSayisi - 2) * 180) / Double(kenarSayisi)
        return toplam
    }
}
// Üçgen hesaplamak için 3, dörgen için 4, çokgen için kaç kenarlıysa o sayıyı yazmamız yeterli

let s5 = Soru5().icAciToplami(kenarSayisi: 3)
print("Üçgenin her bir iç açısının derecesi: \(s5), Üçgenin iç açılarının toplamı ise : \(s5*3)")




//Girilen gün sayısına göre maaş hesabı yapan birprogram yazınız.
print("Çalışılan gün sayısını girin:")
if let calisilanGunSayisi = Int(readLine() ?? "") {
    
    // Maaş hesaplama
    let gunlukMaasOrani: Double = 100.0 // Günlük maaş oranı (örnek olarak 100 TL)
    let maas = Double(calisilanGunSayisi) * gunlukMaasOrani
    
    // Sonucu ekrana yazdır
    print("Çalışılan gün sayısı: \(calisilanGunSayisi)")
    print("Toplam maaş: \(maas) TL")
    
} else {
    print("Geçerli bir sayı girilmedi.")
}

//Otopark ücreti hesaplayan program

class soru7 {
    func otoparkUcretiHesapla(sure:Int) -> Int {
        let ilkSaat = 50
        let ekSaat  = 10
        
        if sure <= 0{
            return 0
        }
        else if sure <= 60  {
            return ilkSaat
        }
        else if sure > 60 {
            let saatlikUcret = ilkSaat + (sure / 60 - 1) * ekSaat
            return saatlikUcret
        }else {
            return 0
        }
    }
}


let ucretHesaplama = soru7()
let ucret = ucretHesaplama.otoparkUcretiHesapla(sure: 150)// örneğin 120 dakkika durduk diyelim
print(ucret)




